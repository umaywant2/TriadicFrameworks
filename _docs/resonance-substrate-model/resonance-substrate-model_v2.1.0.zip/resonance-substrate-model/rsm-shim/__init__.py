# Minimal RSM shim package
